from django.apps import AppConfig


class StateConfig(AppConfig):
    name = 'state'
